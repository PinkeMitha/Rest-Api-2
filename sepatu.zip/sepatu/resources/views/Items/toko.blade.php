@extends('layouts.app')
@section('title', 'Krupuk Jenni')
@section('content')

@endsection